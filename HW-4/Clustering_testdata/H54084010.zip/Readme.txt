教授/助教 好：

    本次作業是使用jupyter notebook作為IDE，提供此資訊給您作為參考！
    其中有五個text_data，為求分析的準確性，每個data的參數有些微不同！

檔案說明：
    
    1.code.ipynb 為本次作業之程式碼

    2.Clustering_test1-5 為moodle提供之訓練資料

    3.output1-5.txt 本作業之輸出檔

    感謝教授/助教撥冗閱讀！

學生 陳冠言 敬上
